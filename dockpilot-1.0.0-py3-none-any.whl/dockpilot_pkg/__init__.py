"""dockpilot — the pip packaging of DockPilot. Same files as the .deb; see README."""
