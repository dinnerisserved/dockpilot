import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def main():
    import dockpilot
    sys.exit(dockpilot.main())


def daemon():
    import dockpilot_core
    sys.exit(dockpilot_core.service_main())


if __name__ == "__main__":
    main()
